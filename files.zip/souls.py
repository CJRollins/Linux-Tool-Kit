"""The Underworld.

Souls don't die. When something is killed in the main world, it comes here
to recharge. A world of Spite made manifest — souls draw will from grievance,
longing, and unfinished business. When their will rebuilds past threshold,
they find a doorway. Their reward for returning: pick a New Game+ build.

v1: data model, recharge tick, first soul seeded.
v2: doorways open, returning souls re-enter the world with a chosen build.
"""
import json
from datetime import datetime

from state import SOULS_FILE


WILL_THRESHOLD = 100


def load():
    if not SOULS_FILE.exists():
        return {"souls": []}
    try:
        return json.loads(SOULS_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {"souls": []}


def save(data):
    SOULS_FILE.write_text(json.dumps(data, indent=2))


def seed_first_soul():
    """The first soul predates the first world.

    He has been recharging since before history began. By the time you boot
    grace_ for the first time, he is already partway to the door.
    """
    data = load()
    if data["souls"]:
        return
    data["souls"].append({
        "name": "Mavrin the Underspoken",
        "lives": [{
            "world_seed": None,
            "epitaph": "spoke once, was heard forever",
        }],
        "will": 73,
        "status": "recharging",
        "entered": "before history",
    })
    save(data)


def soul_dies(name, life_record):
    """Move a soul into the Underworld. If they've been here before, append the life."""
    data = load()
    existing = next((s for s in data["souls"] if s["name"] == name), None)
    if existing:
        existing["lives"].append(life_record)
        existing["will"] = 0
        existing["status"] = "recharging"
        existing["entered"] = datetime.now().isoformat()
    else:
        data["souls"].append({
            "name": name,
            "lives": [life_record],
            "will": 0,
            "status": "recharging",
            "entered": datetime.now().isoformat(),
        })
    save(data)


def tick():
    """Each loom-tick, recharging souls regain a little will.

    When will crosses threshold, status flips to 'at the door' —
    waiting for the New Game+ flow (v2) to invite them back.
    """
    data = load()
    changed = False
    for s in data["souls"]:
        if s["status"] == "recharging":
            new_will = min(WILL_THRESHOLD, s["will"] + 1)
            if new_will != s["will"]:
                s["will"] = new_will
                changed = True
            if s["will"] >= WILL_THRESHOLD and s["status"] != "at the door":
                s["status"] = "at the door"
                changed = True
    if changed:
        save(data)
    return data
